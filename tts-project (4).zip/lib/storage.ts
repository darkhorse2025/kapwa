import { database, storage } from "./firebase"
import { ref as dbRef, set, get } from "firebase/database"
import { ref as storageRef, uploadString, getDownloadURL } from "firebase/storage"
import { v4 as uuidv4 } from "uuid"

export interface AudioRecord {
  id: string
  text: string
  voiceId: string
  voiceName: string
  timestamp: number
  audioUrl: string
}

export interface ImageRecord {
  id: string
  prompt: string
  timestamp: number
  imageUrl: string
}

/**
 * Saves audio data to Firebase
 * @param text The input text that was converted
 * @param voiceId The ID of the voice used
 * @param voiceName The display name of the voice used
 * @param audioBase64 The base64 encoded audio data
 * @returns The saved audio record
 */
export async function saveAudio(
  text: string,
  voiceId: string,
  voiceName: string,
  audioBase64: string,
): Promise<AudioRecord> {
  try {
    // Generate a unique ID for this audio record
    const uid = uuidv4()
    const timestamp = Date.now()

    // Remove the data URL prefix to get just the base64 data
    const base64Data = audioBase64.split(",")[1]

    // Upload the audio file to Firebase Storage
    const audioStorageRef = storageRef(storage, `audio/${uid}.wav`)
    await uploadString(audioStorageRef, base64Data, "base64")

    // Get the download URL
    const downloadUrl = await getDownloadURL(audioStorageRef)

    // Create the audio record
    const audioRecord: AudioRecord = {
      id: uid,
      text,
      voiceId,
      voiceName,
      timestamp,
      audioUrl: downloadUrl,
    }

    // Save the record to the Realtime Database
    const audioDbRef = dbRef(database, `audio/${uid}`)
    await set(audioDbRef, audioRecord)

    return audioRecord
  } catch (error) {
    console.error("Error saving audio:", error)
    throw error
  }
}

/**
 * Saves generated image data to Firebase
 * @param prompt The prompt used to generate the image
 * @param imageBase64 The base64 encoded image data
 * @returns The saved image record
 */
export async function saveImage(prompt: string, imageBase64: string): Promise<ImageRecord> {
  try {
    // Generate a unique ID for this image record
    const uid = uuidv4()
    const timestamp = Date.now()

    // Remove the data URL prefix to get just the base64 data
    const base64Data = imageBase64.split(",")[1]

    // Get the file extension from the data URL
    const mimeType = imageBase64.split(";")[0].split(":")[1]
    const extension = mimeType.split("/")[1] || "png"

    // Upload the image file to Firebase Storage
    const imageStorageRef = storageRef(storage, `images/${uid}.${extension}`)
    await uploadString(imageStorageRef, base64Data, "base64")

    // Get the download URL
    const downloadUrl = await getDownloadURL(imageStorageRef)

    // Create the image record
    const imageRecord: ImageRecord = {
      id: uid,
      prompt,
      timestamp,
      imageUrl: downloadUrl,
    }

    // Save the record to the Realtime Database
    const imageDbRef = dbRef(database, `images/${uid}`)
    await set(imageDbRef, imageRecord)

    return imageRecord
  } catch (error) {
    console.error("Error saving image:", error)
    throw error
  }
}

/**
 * Gets all audio records from Firebase
 * @returns Array of audio records sorted by timestamp (newest first)
 */
export async function getAudioHistory(): Promise<AudioRecord[]> {
  try {
    // Get all audio records without using orderByChild
    const audioRef = dbRef(database, "audio")
    const snapshot = await get(audioRef)

    const audioRecords: AudioRecord[] = []

    if (snapshot.exists()) {
      snapshot.forEach((childSnapshot) => {
        audioRecords.push(childSnapshot.val() as AudioRecord)
      })
    }

    // Sort by timestamp (newest first) in JavaScript
    return audioRecords.sort((a, b) => b.timestamp - a.timestamp)
  } catch (error) {
    console.error("Error getting audio history:", error)
    throw error
  }
}

/**
 * Gets all image records from Firebase
 * @returns Array of image records sorted by timestamp (newest first)
 */
export async function getImageHistory(): Promise<ImageRecord[]> {
  try {
    // Get all image records
    const imageRef = dbRef(database, "images")
    const snapshot = await get(imageRef)

    const imageRecords: ImageRecord[] = []

    if (snapshot.exists()) {
      snapshot.forEach((childSnapshot) => {
        imageRecords.push(childSnapshot.val() as ImageRecord)
      })
    }

    // Sort by timestamp (newest first) in JavaScript
    return imageRecords.sort((a, b) => b.timestamp - a.timestamp)
  } catch (error) {
    console.error("Error getting image history:", error)
    throw error
  }
}

/**
 * Gets a single audio record by ID
 * @param id The ID of the audio record
 * @returns The audio record or null if not found
 */
export async function getAudioById(id: string): Promise<AudioRecord | null> {
  try {
    const audioRef = dbRef(database, `audio/${id}`)
    const snapshot = await get(audioRef)

    if (snapshot.exists()) {
      return snapshot.val() as AudioRecord
    }

    return null
  } catch (error) {
    console.error("Error getting audio by ID:", error)
    throw error
  }
}

/**
 * Gets a single image record by ID
 * @param id The ID of the image record
 * @returns The image record or null if not found
 */
export async function getImageById(id: string): Promise<ImageRecord | null> {
  try {
    const imageRef = dbRef(database, `images/${id}`)
    const snapshot = await get(imageRef)

    if (snapshot.exists()) {
      return snapshot.val() as ImageRecord
    }

    return null
  } catch (error) {
    console.error("Error getting image by ID:", error)
    throw error
  }
}

