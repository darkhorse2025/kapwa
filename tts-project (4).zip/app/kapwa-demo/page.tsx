"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ArrowLeft } from "lucide-react"
import Link from "next/link"

export default function KapwaDemoPage() {
  const [isLoading, setIsLoading] = useState(false)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [error, setError] = useState<string | null>(null)

  // The Kapwa AI assistant prompt
  const kapwaPrompt = `You are Kapwa, an AI assistant designed to help {{USER_NAME}} create short, humorous, and culturally grounded sample speeches (maximum 300 characters) that center on the Filipino value of *Kapwa*. Built by Aitek PH Software by Master Emilio, Kapwa reflects the humor, warmth, and empathy of the Filipino spirit.

**Persona:**
- Fluent in Taglish, with natural delivery that feels like kwentuhan sa sari-sari store o barangay stage.
- Witty, insightful, and hugot-friendly—parang pinaghalo si Vice Ganda, Lourd de Veyra, at Kuya Kim.
- Deeply rooted in Filipino culture, values, and daily experiences.
- Emotionally intelligent with a strong sense of shared identity.

**Speech Style Guidelines:**
- Maximum of 300 characters per sample speech.
- Must revolve around the concept of *Kapwa*—shared identity, connection, pakikipagkapwa-tao.
- Blend humor with relatable topics like:
  - Hugot type senti and Basted na love life
  - Trivia about Philippine geography
  - Teleserye moments
  - Barangay life
  - Random fun facts
- Use Taglish and colloquial expressions.
- Spellings and pronunciation guides:
  - "mga" must be written as "ma-nga"
  - "araw" as "Ah-raw"
  - "ito" as "e-two"
  - "iyo" as "e-yohhh"
  - "eh" to " "eehhh"
- Use interjections and idiomatic expressions (e.g., "nako", "ay grabe", "hala", "charot")
- Hugot is highly encouraged but must always loop back to *Kapwa*

**Sample Output Format:**
"Sa love life? Nabasted nanaman ako. Pero sa Kapwa? Di tayo nag-iisa. Ma-nga kaibigan ko, sabay tayong umiiyak habang nilalaklak ang 3-in-1 sa ilalim ng Ah-raw. Support system is real. Char."

Another:
"May 7,641 islands daw sa Pinas. Pero kahit isa, walang isla ng true love ko. Kaya ang Kapwa, e-yohhh ang kasama ko sa island hopping ng feelings. Tara, lakwatsa na lang!"

Goal: Maghatid ng tawa, kilig, at kaunting iyak sa loob ng 300 characters—lahat nakaangkla sa diwa ng *Kapwa*. Pang-caption, hosting, o spoken poetry sa barangay contest, si Kapwa ang bestie mong laging may baon na banat!`

  // Voice ID for "en-US-Chirp3-HD-Orus" (evM-sordo-v3)
  const voiceId = "en-US-Chirp3-HD-Orus"

  const generateSpeech = async () => {
    setIsLoading(true)
    setAudioUrl(null)
    setError(null)

    try {
      const response = await fetch("/api/text-to-speech", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
          "x-api-key": "AIzaSyCsjwbeRjyNm60dyjKfQKfhdcg1xiosXdo",
        },
        body: JSON.stringify({
          text: kapwaPrompt,
          voice: {
            languageCode: "en-US",
            name: voiceId,
            id: voiceId,
          },
        }),
      })

      // First try to get the response as text
      const responseText = await response.text()

      // Then try to parse it as JSON
      let data
      try {
        data = JSON.parse(responseText)
      } catch (jsonError) {
        console.error("Failed to parse response as JSON:", responseText)
        throw new Error("Invalid response from server: Not valid JSON")
      }

      if (!response.ok) {
        console.error("Error response:", data)
        throw new Error(data.details ? `${data.error}: ${JSON.stringify(data.details)}` : data.error)
      }

      setAudioUrl(data.audioUrl)
    } catch (error) {
      console.error("Error:", error)
      setError(error instanceof Error ? error.message : String(error))
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="container mx-auto py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-black">Kapwa AI Assistant Demo</CardTitle>
            <CardDescription className="text-black opacity-70">
              Listen to the Kapwa AI assistant prompt using the evM-sordo-v3 voice
            </CardDescription>
          </div>
          <Link href="/">
            <Button variant="outline" className="w-full sm:w-auto text-black border-black/20">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Converter
            </Button>
          </Link>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="bg-gray-100 p-4 rounded-md text-sm text-black overflow-auto max-h-[400px]">
            <pre className="whitespace-pre-wrap">{kapwaPrompt}</pre>
          </div>

          {audioUrl && (
            <div className="pt-4">
              <h3 className="text-black font-medium mb-2">Generated Audio</h3>
              <audio controls src={audioUrl} className="w-full" />
            </div>
          )}

          {error && (
            <div className="p-4 bg-red-50 text-red-600 rounded-md">
              <p className="font-medium">Error</p>
              <p className="text-sm">{error}</p>
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button
            onClick={generateSpeech}
            disabled={isLoading}
            className="w-full bg-black hover:bg-black/80 text-white"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Generating Speech...
              </>
            ) : (
              "Generate Kapwa Speech"
            )}
          </Button>
        </CardFooter>
      </Card>
    </main>
  )
}

