"use client"

import { useState, useEffect } from "react"
import { Card, CardContent, CardDescription, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Loader2, Download, ArrowLeft } from "lucide-react"
import Link from "next/link"
import type { ImageRecord } from "@/lib/storage"

export default function ImagesPage() {
  const [imageRecords, setImageRecords] = useState<ImageRecord[]>([])
  const [isLoading, setIsLoading] = useState(true)
  const [error, setError] = useState<string | null>(null)

  useEffect(() => {
    const fetchImageHistory = async () => {
      try {
        setIsLoading(true)
        setError(null)

        const response = await fetch("/api/images")

        if (!response.ok) {
          const errorData = await response.json()
          throw new Error(errorData.error || "Failed to fetch image history")
        }

        const data = await response.json()
        setImageRecords(data.imageRecords || [])
      } catch (error) {
        console.error("Error fetching image history:", error)
        setError(error instanceof Error ? error.message : "An unknown error occurred")
      } finally {
        setIsLoading(false)
      }
    }

    fetchImageHistory()
  }, [])

  const formatDate = (timestamp: number) => {
    return new Date(timestamp).toLocaleString()
  }

  const downloadImage = async (imageUrl: string, fileName: string) => {
    try {
      const response = await fetch(imageUrl)
      const blob = await response.blob()
      const url = window.URL.createObjectURL(blob)
      const a = document.createElement("a")
      a.style.display = "none"
      a.href = url
      a.download = fileName
      document.body.appendChild(a)
      a.click()
      window.URL.revokeObjectURL(url)
    } catch (error) {
      console.error("Error downloading image:", error)
      alert("Failed to download image. Please try again.")
    }
  }

  return (
    <main className="container mx-auto px-4 py-6 md:py-8">
      <Card className="w-full mx-auto">
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-black text-xl md:text-2xl">Generated Images</CardTitle>
            <CardDescription className="text-black opacity-70">Your previous AI-generated images</CardDescription>
          </div>
          <Link href="/">
            <Button variant="outline" className="w-full sm:w-auto text-black border-black/20">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Generator
            </Button>
          </Link>
        </CardHeader>
        <CardContent>
          {isLoading ? (
            <div className="flex justify-center py-6 md:py-8">
              <Loader2 className="w-6 h-6 md:w-8 md:h-8 animate-spin text-black" />
            </div>
          ) : error ? (
            <div className="text-center py-6 md:py-8 text-red-500">
              <p>Error: {error}</p>
              <p className="mt-2 text-sm">Please try again later or contact support.</p>
            </div>
          ) : imageRecords.length === 0 ? (
            <div className="text-center py-6 md:py-8 text-black">
              <p>No generated images found.</p>
            </div>
          ) : (
            <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
              {imageRecords.map((record) => (
                <div key={record.id} className="border border-black/20 rounded-lg p-3 md:p-4 space-y-2 md:space-y-3">
                  <div className="space-y-2">
                    <h3 className="font-medium text-black text-sm md:text-base line-clamp-2">{record.prompt}</h3>
                    <p className="text-xs text-black/70">{formatDate(record.timestamp)}</p>
                  </div>
                  <div className="relative aspect-square overflow-hidden rounded-md bg-gray-100">
                    <img
                      src={record.imageUrl || "/placeholder.svg"}
                      alt={record.prompt}
                      className="object-cover w-full h-full"
                    />
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    className="text-black border-black/20 w-full"
                    onClick={() => downloadImage(record.imageUrl, `image-${record.id}.png`)}
                  >
                    <Download className="w-4 h-4 mr-2" />
                    Download
                  </Button>
                </div>
              ))}
            </div>
          )}
        </CardContent>
      </Card>
    </main>
  )
}

