import { type NextRequest, NextResponse } from "next/server"
import { getImageById } from "@/lib/storage"

/**
 * GET /api/images/[id]
 * Gets a single image record by ID
 */
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    if (!id) {
      return NextResponse.json({ error: "Missing image ID" }, { status: 400 })
    }

    const imageRecord = await getImageById(id)

    if (!imageRecord) {
      return NextResponse.json({ error: "Image record not found" }, { status: 404 })
    }

    return NextResponse.json({ imageRecord })
  } catch (error) {
    console.error("Error getting image by ID:", error)
    return NextResponse.json({ error: "Failed to get image record" }, { status: 500 })
  }
}

