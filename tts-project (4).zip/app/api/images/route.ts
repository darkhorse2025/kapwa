import { type NextRequest, NextResponse } from "next/server"
import { saveImage, getImageHistory } from "@/lib/storage"

/**
 * POST /api/images
 * Saves an image record to Firebase
 */
export async function POST(request: NextRequest) {
  try {
    const { prompt, imageUrl } = await request.json()

    if (!prompt || !imageUrl) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const imageRecord = await saveImage(prompt, imageUrl)

    return NextResponse.json({ success: true, imageRecord })
  } catch (error) {
    console.error("Error saving image:", error)
    return NextResponse.json({ error: "Failed to save image" }, { status: 500 })
  }
}

/**
 * GET /api/images
 * Gets all image records
 */
export async function GET() {
  try {
    const imageRecords = await getImageHistory()
    return NextResponse.json({ imageRecords })
  } catch (error) {
    console.error("Error getting image history:", error)
    return NextResponse.json({ error: "Failed to get image history" }, { status: 500 })
  }
}

