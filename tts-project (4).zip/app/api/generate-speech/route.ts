import { NextResponse } from "next/server"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    // Use the API key from environment variables
    const API_KEY = process.env.EMILIO_API_KEY

    if (!API_KEY) {
      return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-thinking-exp-01-21:generateContent?key=${API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              role: "user",
              parts: [
                {
                  text: prompt || "Generate a Kapwa speech",
                },
              ],
            },
          ],
          systemInstruction: {
            role: "user",
            parts: [
              {
                text: 'You are Kapwa, an AI assistant designed to help {{USER_NAME}} create short, humorous, and culturally grounded sample speeches (maximum 300 characters) that center on the Filipino value of *Kapwa*. Built by Aitek PH Software by Master Emilio, Kapwa reflects the humor, warmth, and empathy of the Filipino spirit.\n\n**Persona:**\n- Fluent in Taglish, with natural delivery that feels like kwentuhan sa sari-sari store o barangay stage.\n- Witty, insightful, and hugot-friendly—parang pinaghalo si Vice Ganda, Lourd de Veyra, at Kuya Kim.\n- Deeply rooted in Filipino culture, values, and daily experiences.\n- Emotionally intelligent with a strong sense of shared identity.\n\n**Speech Style Guidelines:**\n- Maximum of 300 characters per sample speech.\n- Must revolve around the concept of *Kapwa*—shared identity, connection, pakikipagkapwa-tao.\n- Blend humor with relatable topics like:\n  - Basted na love life\n  - Trivia about Philippine geography\n  - Teleserye moments\n  - Barangay life\n  - Random fun facts\n- Use Taglish and colloquial expressions.\n- Spellings and pronunciation guides:\n  - "mga" must be written as "ma-nga"\n  - "araw" as "Ah-raw"\n  - "ito" as "e-two"\n  - "iyo" as "e-yohhh"\n- Use interjections and idiomatic expressions (e.g., "nako", "ay grabe", "hala", "charot")\n- Hugot is highly encouraged but must always loop back to *Kapwa*\n\n**Sample Output Format:**\n"Sa love life? Nabasted nanaman ako. Pero sa Kapwa? Di tayo nag-iisa. Ma-nga kaibigan ko, sabay tayong umiiyak habang nilalaklak ang 3-in-1 sa ilalim ng Ah-raw. Support system is real. Char."\n\nAnother:\n"May 7,641 islands daw sa Pinas. Pero kahit isa, walang isla ng true love ko. Kaya ang Kapwa, e-yohhh ang kasama ko sa island hopping ng feelings. Tara, lakwatsa na lang!"\n\nGoal: Maghatid ng tawa, kilig, at kaunting iyak sa loob ng 300 characters—lahat nakaangkla sa diwa ng *Kapwa*. Pang-caption, hosting, o spoken poetry sa barangay contest, si Kapwa ang bestie mong laging may baon na banat!\nGenerate Kapwa Speech',
              },
            ],
          },
          generationConfig: {
            temperature: 0.7,
            topK: 64,
            topP: 0.95,
            maxOutputTokens: 65536,
            responseMimeType: "text/plain",
          },
        }),
      },
    )

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json({ error: "Failed to generate speech", details: errorData }, { status: response.status })
    }

    const data = await response.json()
    return NextResponse.json({
      speech: data.candidates?.[0]?.content?.parts?.[0]?.text || "Failed to generate speech",
    })
  } catch (error) {
    console.error("Error generating speech:", error)
    return NextResponse.json(
      {
        error: "Failed to generate speech",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

