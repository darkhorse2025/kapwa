import { NextResponse } from "next/server"

export async function GET(request: Request) {
  try {
    // Extract the API key from the URL query parameter
    const url = new URL(request.url)
    const apiKey = url.searchParams.get("key")

    if (!apiKey) {
      return NextResponse.json(
        {
          status: "error",
          message: "API key is not provided",
        },
        { status: 400 },
      )
    }

    // Make a simple request to the Google TTS API to check if the key is valid
    const response = await fetch(`https://texttospeech.googleapis.com/v1/voices?key=${apiKey}`, {
      method: "GET",
      headers: {
        "Content-Type": "application/json",
      },
    })

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json(
        {
          status: "error",
          message: "API key validation failed",
          details: errorData,
        },
        { status: response.status },
      )
    }

    return NextResponse.json({
      status: "success",
      message: "API key is valid",
    })
  } catch (error) {
    console.error("Error testing TTS API key:", error)
    return NextResponse.json(
      {
        status: "error",
        message: "Failed to test API key",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

