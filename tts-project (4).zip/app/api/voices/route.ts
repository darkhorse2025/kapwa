import { NextResponse } from "next/server"

// Define the voice interface
interface Voice {
  id: string
  name: string
  languageCode: string
  gender: "MALE" | "FEMALE"
}

// Create a list of available voices
const availableVoices: Voice[] = [
  { id: "en-US-Chirp3-HD-Aoede", name: "evF-aransag-v1", languageCode: "en-US", gender: "FEMALE" },
  { id: "en-US-Chirp3-HD-Charon", name: "evM-sordo-v1", languageCode: "en-US", gender: "MALE" },
  { id: "en-US-Chirp3-HD-Fenrir", name: "evM-sordo-v2", languageCode: "en-US", gender: "MALE" },
  { id: "en-US-Chirp3-HD-Kore", name: "evF-makahiya-v1", languageCode: "en-US", gender: "FEMALE" },
  { id: "en-US-Chirp3-HD-Leda", name: "evF-aransag-v2", languageCode: "en-US", gender: "FEMALE" },
  { id: "en-US-Chirp3-HD-Orus", name: "evM-sordo-v3", languageCode: "en-US", gender: "MALE" },
  { id: "en-US-Chirp3-HD-Puck", name: "evM-sordo-v4", languageCode: "en-US", gender: "MALE" },
  { id: "en-US-Chirp3-HD-Zephyr", name: "evF-makahiya-v2", languageCode: "en-US", gender: "FEMALE" },
]

export async function GET() {
  try {
    console.log("Returning available voices:", availableVoices)
    return NextResponse.json({ voices: availableVoices })
  } catch (error) {
    console.error("Server error in voices API:", error)
    return NextResponse.json({ error: "Internal server error" }, { status: 500 })
  }
}

