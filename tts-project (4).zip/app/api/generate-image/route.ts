import { NextResponse } from "next/server"
import { saveImage } from "@/lib/storage"

export async function POST(request: Request) {
  try {
    const { prompt } = await request.json()

    if (!prompt) {
      return NextResponse.json({ error: "Prompt is required" }, { status: 400 })
    }

    // Use the API key from environment variables
    const API_KEY = process.env.EMILIO_API_KEY

    if (!API_KEY) {
      return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
    }

    const response = await fetch(
      `https://generativelanguage.googleapis.com/v1beta/models/gemini-2.0-flash-exp-image-generation:generateContent?key=${API_KEY}`,
      {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          contents: [
            {
              role: "user",
              parts: [
                {
                  text: prompt,
                },
              ],
            },
          ],
          generationConfig: {
            temperature: 1,
            topK: 40,
            topP: 0.95,
            maxOutputTokens: 8192,
            responseMimeType: "text/plain",
            responseModalities: ["image", "text"],
          },
        }),
      },
    )

    if (!response.ok) {
      const errorData = await response.json()
      return NextResponse.json(
        {
          error: "Failed to generate image",
          details: errorData,
        },
        { status: response.status },
      )
    }

    const data = await response.json()

    // Extract the image data from the response
    const imageData = data.candidates?.[0]?.content?.parts?.find((part) =>
      part.inlineData?.mimeType?.startsWith("image/"),
    )

    if (!imageData) {
      return NextResponse.json(
        {
          error: "No image generated in response",
          rawResponse: data,
        },
        { status: 500 },
      )
    }

    const imageUrl = `data:${imageData.inlineData.mimeType};base64,${imageData.inlineData.data}`

    // Save the image to Firebase
    const imageRecord = await saveImage(prompt, imageUrl)

    return NextResponse.json({
      imageUrl,
      imageRecord,
      text: data.candidates?.[0]?.content?.parts?.find((part) => part.text)?.text || "",
    })
  } catch (error) {
    console.error("Error generating image:", error)
    return NextResponse.json(
      {
        error: "Failed to generate image",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

