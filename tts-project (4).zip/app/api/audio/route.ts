import { type NextRequest, NextResponse } from "next/server"
import { saveAudio, getAudioHistory } from "@/lib/storage"

/**
 * POST /api/audio
 * Saves an audio record to Firebase
 */
export async function POST(request: NextRequest) {
  try {
    const { text, voiceId, voiceName, audioBase64 } = await request.json()

    if (!text || !voiceId || !voiceName || !audioBase64) {
      return NextResponse.json({ error: "Missing required fields" }, { status: 400 })
    }

    const audioRecord = await saveAudio(text, voiceId, voiceName, audioBase64)

    return NextResponse.json({ success: true, audioRecord })
  } catch (error) {
    console.error("Error saving audio:", error)
    return NextResponse.json({ error: "Failed to save audio" }, { status: 500 })
  }
}

/**
 * GET /api/audio
 * Gets all audio records
 */
export async function GET() {
  try {
    const audioRecords = await getAudioHistory()
    return NextResponse.json({ audioRecords })
  } catch (error) {
    console.error("Error getting audio history:", error)
    return NextResponse.json({ error: "Failed to get audio history" }, { status: 500 })
  }
}

