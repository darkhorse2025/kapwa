import { type NextRequest, NextResponse } from "next/server"
import { getAudioById } from "@/lib/storage"

/**
 * GET /api/audio/[id]
 * Gets a single audio record by ID
 */
export async function GET(request: NextRequest, { params }: { params: { id: string } }) {
  try {
    const id = params.id

    if (!id) {
      return NextResponse.json({ error: "Missing audio ID" }, { status: 400 })
    }

    const audioRecord = await getAudioById(id)

    if (!audioRecord) {
      return NextResponse.json({ error: "Audio record not found" }, { status: 404 })
    }

    return NextResponse.json({ audioRecord })
  } catch (error) {
    console.error("Error getting audio by ID:", error)
    return NextResponse.json({ error: "Failed to get audio record" }, { status: 500 })
  }
}

