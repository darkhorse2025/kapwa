import { type NextRequest, NextResponse } from "next/server"
import { saveAudio } from "@/lib/audio-storage"

export async function POST(request: NextRequest) {
  try {
    const { text, voice } = await request.json()

    if (!text || !voice) {
      return NextResponse.json({ error: "Text and voice are required" }, { status: 400 })
    }

    // Get API key from environment variable or request
    const apiKey = request.headers.get("x-api-key") || process.env.EMILIO_API_KEY

    if (!apiKey) {
      console.error("API key is missing")
      return NextResponse.json({ error: "API key is not configured" }, { status: 500 })
    }

    console.log("Making request to Google TTS API with voice:", voice)

    const payload = {
      input: {
        text,
      },
      voice: {
        languageCode: voice.languageCode,
        name: voice.id || voice.name, // Try using voice.id if available
      },
      audioConfig: {
        audioEncoding: "LINEAR16",
        sampleRateHertz: 24000,
      },
    }

    console.log("Request payload:", JSON.stringify(payload))

    const response = await fetch(`https://texttospeech.googleapis.com/v1/text:synthesize?key=${apiKey}`, {
      method: "POST",
      headers: {
        "Content-Type": "application/json",
      },
      body: JSON.stringify(payload),
    })

    // Get the raw response text first
    const responseText = await response.text()

    // Try to parse as JSON
    let data
    try {
      data = JSON.parse(responseText)
    } catch (jsonError) {
      console.error("Invalid JSON in response:", responseText)
      return NextResponse.json(
        {
          error: "Invalid response from Google TTS API",
          details: responseText.substring(0, 200) + (responseText.length > 200 ? "..." : ""),
        },
        { status: 500 },
      )
    }

    if (!response.ok) {
      console.error("Google TTS API error:", data)
      return NextResponse.json(
        {
          error: "Failed to convert text to speech",
          details: data,
        },
        { status: response.status },
      )
    }

    // Check if audioContent exists in the response
    if (!data.audioContent) {
      console.error("No audio content in response:", data)
      return NextResponse.json(
        {
          error: "No audio content in response",
          details: data,
        },
        { status: 500 },
      )
    }

    // The API returns base64 encoded audio content
    // We'll create a data URL that can be used in an audio element
    const audioUrl = `data:audio/wav;base64,${data.audioContent}`

    // Get the voice name from the voices API
    const voicesResponse = await fetch(`${request.nextUrl.origin}/api/voices`)
    const voicesData = await voicesResponse.json()
    const voiceName = voicesData.voices.find((v: any) => v.id === voice.name)?.name || voice.name

    // Save the audio to Firebase
    const audioRecord = await saveAudio(text, voice.name, voiceName, audioUrl)

    return NextResponse.json({ audioUrl, audioRecord })
  } catch (error) {
    console.error("Server error:", error)
    return NextResponse.json(
      {
        error: "Internal server error",
        details: error instanceof Error ? error.message : String(error),
      },
      { status: 500 },
    )
  }
}

