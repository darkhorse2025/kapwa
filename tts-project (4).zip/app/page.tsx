"use client"

import type React from "react"

import { useState, useEffect, useCallback } from "react"
import { Button } from "@/components/ui/button"
import { Textarea } from "@/components/ui/textarea"
import { Card, CardContent, CardHeader } from "@/components/ui/card"
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select"
import { Label } from "@/components/ui/label"
import { Loader2, History, FileText, ImageIcon, AlertCircle, Images } from "lucide-react"
import Link from "next/link"
import type { AudioRecord, ImageRecord } from "@/lib/storage"
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs"
import { Input } from "@/components/ui/input"
import { Alert, AlertDescription, AlertTitle } from "@/components/ui/alert"

export default function TextToSpeechPage() {
  // Initialize text state as an empty string
  const [text, setText] = useState("")
  const [voices, setVoices] = useState<Array<{ id: string; name: string }>>([])
  const [voice, setVoice] = useState("")
  const [isLoadingVoices, setIsLoadingVoices] = useState(true)
  // Fixed language code since we're only using English voices
  const languageCode = "en-US"
  const [isLoading, setIsLoading] = useState(false)
  const [audioUrl, setAudioUrl] = useState<string | null>(null)
  const [audioRecord, setAudioRecord] = useState<AudioRecord | null>(null)
  const [error, setError] = useState<string | null>(null)

  // Image generation states
  const [imagePrompt, setImagePrompt] = useState("")
  const [isGeneratingImage, setIsGeneratingImage] = useState(false)
  const [generatedImage, setGeneratedImage] = useState<string | null>(null)
  const [imageError, setImageError] = useState<string | null>(null)
  const [imageRecord, setImageRecord] = useState<ImageRecord | null>(null)

  const sampleText =
    "Magandang ahh raw, champions! Ako si Emilio, pero hindi yung dating presidente ah, haha! So nga-yon gusto mo bang gumawa nang text to speech na hindi mukhang robot? Haha, Allright, start na tayo."

  useEffect(() => {
    const fetchVoices = async () => {
      try {
        const response = await fetch("/api/voices")
        if (!response.ok) {
          throw new Error("Failed to fetch voices")
        }
        const data = await response.json()
        setVoices(data.voices)

        // Set default voice if available
        if (data.voices.length > 0) {
          setVoice(data.voices[0].id)
        }
      } catch (error) {
        console.error("Error fetching voices:", error)
      } finally {
        setIsLoadingVoices(false)
      }
    }

    fetchVoices()
  }, [])

  // Update the handleSubmit function to provide better error handling and user feedback

  const handleSubmit = async () => {
    setIsLoading(true)
    setAudioUrl(null)
    setAudioRecord(null)
    setError(null)

    try {
      console.log("Submitting text:", text)
      console.log("Selected voice:", voice)

      const response = await fetch("/api/text-to-speech", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          text,
          voice: {
            languageCode,
            name: voice,
            id: voice, // Add id field to ensure it's available
          },
        }),
      })

      // First try to get the response as text
      const responseText = await response.text()

      // Then try to parse it as JSON
      let data
      try {
        data = JSON.parse(responseText)
      } catch (jsonError) {
        console.error("Failed to parse response as JSON:", responseText)
        throw new Error(
          `Invalid response from server: Not valid JSON. Response starts with: ${responseText.substring(0, 50)}...`,
        )
      }

      if (!response.ok) {
        console.error("Error response:", data)
        throw new Error(data.details ? `${data.error}: ${JSON.stringify(data.details)}` : data.error)
      }

      if (!data.audioUrl) {
        throw new Error("No audio URL in response")
      }

      setAudioUrl(data.audioUrl)
      setAudioRecord(data.audioRecord)
    } catch (error) {
      console.error("Error:", error)
      setError(error instanceof Error ? error.message : String(error))
    } finally {
      setIsLoading(false)
    }
  }

  // Handle text change
  const handleTextChange = (e: React.ChangeEvent<HTMLTextAreaElement>) => {
    setText(e.target.value)
  }

  // Use sample text from Gemini API
  const useSampleText = useCallback(async () => {
    try {
      setIsLoading(true)
      setError(null)
      const response = await fetch("/api/generate-speech", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt: "Generate a Kapwa speech" }),
      })

      if (!response.ok) {
        throw new Error("Failed to generate sample text")
      }

      const data = await response.json()
      setText(data.speech)
    } catch (error) {
      console.error("Error generating sample text:", error)
      // Fallback to the static sample text if API call fails
      setText(sampleText)
    } finally {
      setIsLoading(false)
    }
  }, [sampleText])

  // Generate image
  const generateImage = async () => {
    if (!imagePrompt.trim()) {
      setImageError("Please enter an image prompt")
      return
    }

    setIsGeneratingImage(true)
    setGeneratedImage(null)
    setImageError(null)
    setImageRecord(null)

    try {
      const response = await fetch("/api/generate-image", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({ prompt: imagePrompt }),
      })

      const data = await response.json()

      if (!response.ok) {
        console.error("Error generating image:", data)
        throw new Error(data.details ? `${data.error}: ${JSON.stringify(data.details)}` : data.error)
      }

      setGeneratedImage(data.imageUrl)
      setImageRecord(data.imageRecord)
    } catch (error) {
      console.error("Error:", error)
      setImageError(error instanceof Error ? error.message : String(error))
    } finally {
      setIsGeneratingImage(false)
    }
  }

  return (
    <main className="container mx-auto py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader className="flex flex-row items-center justify-between">
          <div className="grid grid-cols-2 gap-2 w-full">
            <Link href="/images">
              <Button variant="outline" className="text-black border-black/20 w-full">
                <Images className="w-4 h-4 mr-2" />
                Images
              </Button>
            </Link>
            <Link href="/history">
              <Button variant="outline" className="text-black border-black/20 w-full">
                <History className="w-4 h-4 mr-2" />
                History
              </Button>
            </Link>
            <Link href="/kapwa-demo">
              <Button variant="outline" className="text-black border-black/20 w-full">
                Kapwa Demo
              </Button>
            </Link>
            <Link href="/setup-api-key">
              <Button variant="outline" className="text-black border-black/20 w-full">
                Setup API Key
              </Button>
            </Link>
          </div>
        </CardHeader>
        <CardContent className="space-y-4">
          <Tabs defaultValue="text-to-speech" className="w-full">
            <TabsList className="grid grid-cols-2 mb-4">
              <TabsTrigger value="text-to-speech">Text to Speech</TabsTrigger>
              <TabsTrigger value="image-generation">Image Generation</TabsTrigger>
            </TabsList>

            <TabsContent value="text-to-speech" className="space-y-4">
              {error && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{error}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <div className="flex justify-between items-center">
                  <Label htmlFor="text" className="text-black">
                    Text to convert
                  </Label>
                  <Button
                    variant="ghost"
                    size="sm"
                    onClick={useSampleText}
                    className="text-black/70 hover:text-black"
                    disabled={isLoading}
                  >
                    <FileText className="w-4 h-4 mr-1" />
                    {isLoading ? "Generating..." : "Use sample text"}
                  </Button>
                </div>
                <Textarea
                  id="text"
                  placeholder="Enter text here..."
                  value={text}
                  onChange={handleTextChange}
                  rows={8}
                  className="resize-none text-black border-black/20"
                />
              </div>

              <div className="space-y-2">
                <Label htmlFor="voice" className="text-black">
                  Voice
                </Label>
                <Select value={voice} onValueChange={setVoice} disabled={isLoadingVoices}>
                  <SelectTrigger id="voice" className="text-black border-black/20">
                    <SelectValue placeholder={isLoadingVoices ? "Loading voices..." : "Select voice"} />
                  </SelectTrigger>
                  <SelectContent className="text-black">
                    {voices.map((v) => (
                      <SelectItem key={v.id} value={v.id}>
                        {v.name}
                      </SelectItem>
                    ))}
                  </SelectContent>
                </Select>
              </div>

              {audioUrl && (
                <div className="pt-4">
                  <Label htmlFor="audio-player" className="text-black">
                    Generated Audio
                  </Label>
                  <audio id="audio-player" controls src={audioUrl} className="w-full mt-2" />
                </div>
              )}

              <Button
                onClick={handleSubmit}
                disabled={isLoading || !text.trim()}
                className="w-full bg-black hover:bg-black/80 text-white mt-4"
              >
                {isLoading ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Converting...
                  </>
                ) : (
                  "Convert to Speech"
                )}
              </Button>
            </TabsContent>

            <TabsContent value="image-generation" className="space-y-4">
              {imageError && (
                <Alert variant="destructive">
                  <AlertCircle className="h-4 w-4" />
                  <AlertTitle>Error</AlertTitle>
                  <AlertDescription>{imageError}</AlertDescription>
                </Alert>
              )}

              <div className="space-y-2">
                <Label htmlFor="image-prompt" className="text-black">
                  Image Prompt
                </Label>
                <Input
                  id="image-prompt"
                  placeholder="Describe the image you want to generate..."
                  value={imagePrompt}
                  onChange={(e) => setImagePrompt(e.target.value)}
                  className="text-black border-black/20"
                />
              </div>

              <Button
                onClick={generateImage}
                disabled={isGeneratingImage || !imagePrompt.trim()}
                className="w-full bg-black hover:bg-black/80 text-white"
              >
                {isGeneratingImage ? (
                  <>
                    <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                    Generating Image...
                  </>
                ) : (
                  <>
                    <ImageIcon className="mr-2 h-4 w-4" />
                    Generate Image
                  </>
                )}
              </Button>

              {generatedImage && (
                <div className="pt-4">
                  <Label className="text-black mb-2 block">Generated Image</Label>
                  <div className="border border-black/20 rounded-md overflow-hidden">
                    <img
                      src={generatedImage || "/placeholder.svg"}
                      alt="Generated from prompt"
                      className="w-full h-auto"
                    />
                  </div>
                </div>
              )}
            </TabsContent>
          </Tabs>
        </CardContent>
      </Card>
    </main>
  )
}

