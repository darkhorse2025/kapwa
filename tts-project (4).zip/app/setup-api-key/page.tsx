"use client"

import { useState } from "react"
import { Button } from "@/components/ui/button"
import { Input } from "@/components/ui/input"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Loader2, ArrowLeft, CheckCircle, XCircle } from "lucide-react"
import Link from "next/link"

export default function SetupApiKeyPage() {
  const [apiKey, setApiKey] = useState("AIzaSyCsjwbeRjyNm60dyjKfQKfhdcg1xiosXdo")
  const [isLoading, setIsLoading] = useState(false)
  const [testResult, setTestResult] = useState<{
    status: "success" | "error"
    message: string
    details?: any
  } | null>(null)

  const testApiKey = async () => {
    if (!apiKey.trim()) {
      setTestResult({
        status: "error",
        message: "Please enter an API key",
      })
      return
    }

    setIsLoading(true)
    setTestResult(null)

    try {
      const response = await fetch(`/api/test-provided-key?key=${encodeURIComponent(apiKey)}`)
      const data = await response.json()

      setTestResult(data)
    } catch (error) {
      console.error("Error testing API key:", error)
      setTestResult({
        status: "error",
        message: "Failed to test API key",
        details: error instanceof Error ? error.message : String(error),
      })
    } finally {
      setIsLoading(false)
    }
  }

  return (
    <main className="container mx-auto py-8">
      <Card className="max-w-3xl mx-auto">
        <CardHeader className="flex flex-col sm:flex-row sm:items-center sm:justify-between gap-4">
          <div>
            <CardTitle className="text-black">Setup API Key</CardTitle>
            <CardDescription className="text-black opacity-70">Test and set up your Emilio API key</CardDescription>
          </div>
          <Link href="/">
            <Button variant="outline" className="w-full sm:w-auto text-black border-black/20">
              <ArrowLeft className="w-4 h-4 mr-2" />
              Back to Converter
            </Button>
          </Link>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="space-y-2">
            <label htmlFor="api-key" className="text-sm font-medium text-black">
              Emilio API Key
            </label>
            <Input
              id="api-key"
              value={apiKey}
              onChange={(e) => setApiKey(e.target.value)}
              className="text-black border-black/20"
              placeholder="Enter your API key"
            />
          </div>

          <div className="bg-gray-100 p-4 rounded-md text-sm text-black">
            <h3 className="font-medium mb-2">How to use this API key:</h3>
            <ol className="list-decimal pl-5 space-y-2">
              <li>Test the API key using the button below to ensure it's valid</li>
              <li>
                If valid, set this API key as an environment variable named{" "}
                <code className="bg-gray-200 px-1 rounded">EMILIO_API_KEY</code> in your Vercel project settings
              </li>
              <li>Redeploy your application for the changes to take effect</li>
            </ol>
          </div>

          {testResult && (
            <div
              className={`p-4 rounded-md ${testResult.status === "success" ? "bg-green-50 text-green-600" : "bg-red-50 text-red-600"}`}
            >
              <div className="flex items-center gap-2">
                {testResult.status === "success" ? (
                  <CheckCircle className="w-5 h-5" />
                ) : (
                  <XCircle className="w-5 h-5" />
                )}
                <p className="font-medium">{testResult.message}</p>
              </div>
              {testResult.details && (
                <pre className="mt-2 text-xs overflow-auto max-h-[200px]">
                  {JSON.stringify(testResult.details, null, 2)}
                </pre>
              )}
            </div>
          )}
        </CardContent>
        <CardFooter>
          <Button
            onClick={testApiKey}
            disabled={isLoading || !apiKey.trim()}
            className="w-full bg-black hover:bg-black/80 text-white"
          >
            {isLoading ? (
              <>
                <Loader2 className="mr-2 h-4 w-4 animate-spin" />
                Testing API Key...
              </>
            ) : (
              "Test API Key"
            )}
          </Button>
        </CardFooter>
      </Card>
    </main>
  )
}

